# Design System Document: Precision & Utility

## 1. Overview & Creative North Star
The North Star for this design system is **"The Kinetic Authority."** 

In the world of fuel price intelligence, we aren't just building a utility; we are building a high-performance instrument. This system moves away from the generic "dashboard" look by embracing **Editorial Utility**—where data density meets luxury editorial spacing. 

We break the "template" mold through intentional asymmetry: imagine map interfaces that bleed into oversized, high-contrast price displays, and station cards that use layered depth instead of rigid borders. The goal is a digital experience that feels as reliable as a high-end automotive gauge and as effortless as a premium concierge service.

---

## 2. Colors: Tonal Depth & Meaning
The palette is rooted in the high-contrast needs of a driver at a fuel station, but refined through a "Material-Premium" lens.

### Primary & Secondary Roles
- **Primary (`primary` #003f87):** Our "Fuel Blue." This is the color of authority. Use it for core navigation and primary actions. To add "soul," use a subtle linear gradient from `primary` to `primary_container` (#0056b3) on large CTA surfaces.
- **Secondary (`secondary` #006e25):** The "Vibe Green." Reserved exclusively for "Value" moments: price drops, savings, and successful price reports. It is a signal of positive movement.
- **Tertiary (`tertiary` #722b00):** Used sparingly for "Alert" or "Low Stock" indicators to provide a sophisticated alternative to standard error reds.

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning. 
Boundaries must be defined solely through background color shifts. For example, a station information block (`surface_container_low`) should sit on the main `background` without a stroke. Let the tonal change create the edge.

### Surface Hierarchy & The "Glass" Rule
Treat the UI as stacked sheets of fine material.
- **Base:** `background` (#f8f9fa).
- **Lower Priority:** `surface_container_low` (#f3f4f5).
- **Interactive Layers:** Use `surface_container_lowest` (#ffffff) for the primary card content to make it "pop" against the gray background.
- **Glassmorphism:** For floating map overlays or navigation bars, use `surface` colors at 80% opacity with a `20px` backdrop-blur. This ensures the map stays visible "under" the UI, creating a sense of environmental awareness.

---

## 3. Typography: Editorial Impact
We utilize a dual-font strategy to balance character with extreme legibility.

- **Display & Headline (Manrope):** This is our "Editorial" voice. Manrope’s geometric structure feels engineered. Use `display-lg` (3.5rem) for fuel prices to make them unmissable.
- **Body & Label (Inter):** The "Utility" voice. Inter is used for all station details, addresses, and timestamps. It is designed for maximum readability at small sizes on mobile devices.

**Hierarchy Note:** Prices are the hero. A price should always be at least two steps larger in the typography scale than its surrounding metadata (e.g., a `display-sm` price next to a `title-sm` currency symbol).

---

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to create "pop"; we use light and tone.

- **The Layering Principle:** Stack containers to create hierarchy. A `surface_container_highest` header suggests it is physically closer to the user than the `surface_container` body.
- **Ambient Shadows:** Only use shadows for "Floating" elements (e.g., a floating action button to report a price). Shadows must be diffused: `box-shadow: 0 12px 32px rgba(25, 28, 29, 0.06)`. The tint is derived from `on_surface`, never pure black.
- **The Ghost Border:** If contrast is failing accessibility on a specific map background, use a "Ghost Border": `outline_variant` at 15% opacity. It should be felt, not seen.

---

## 5. Components

### Buttons
- **Primary:** Rounded-xl (1.5rem) for a friendly yet technical feel. Background: Gradient from `primary` to `primary_container`. Text: `on_primary`.
- **Secondary (The Report Button):** High-contrast `secondary_fixed`. This button should be the most "tactile" element on the screen, designed for one-handed thumb taps at the pump.

### Map Pins (The Signature Component)
- Custom asymmetric pins. Instead of a standard teardrop, use a "Price Capsule" shape (a horizontal pill with `rounded-full`). 
- **Active State:** The capsule expands to show the fuel grade and a subtle `surface_tint` glow.

### Cards & Lists
- **Rule:** Absolute prohibition of divider lines. 
- Separation is achieved via **Vertical White Space** (using the `1.5rem` or `2rem` spacing scale) or by alternating subtle background shades (`surface_container_low` vs `surface_container_highest`).
- **Nesting:** Station cards use `rounded-lg` (1rem). Inside the card, price chips use `rounded-sm` (0.25rem) to create a "nested" visual language that feels organized and professional.

### Input Fields
- Use "Soft-Fill" inputs. No borders. Use `surface_container_high` as the background with a 2px `primary` bottom indicator only when focused. This maintains the "No-Line" rule while providing clear focus states.

---

## 6. Do’s and Don’ts

### Do
- **Do** lean into asymmetry. Place prices off-center if it allows for a more dramatic use of Manrope typography.
- **Do** use "Vibe Green" (`secondary`) for any data point that represents a user saving money.
- **Do** ensure dark mode uses high-contrast `on_surface` (white/near-white) text for visibility against the glare of a car dashboard at night.

### Don't
- **Don't** use 1px borders to separate list items. It creates visual noise and feels like a generic template.
- **Don't** use standard Material Design drop shadows. Keep the interface "flat-but-layered."
- **Don't** mix the font families. Manrope is for "Showing" (Prices/Headlines); Inter is for "Reading" (Data/Details).